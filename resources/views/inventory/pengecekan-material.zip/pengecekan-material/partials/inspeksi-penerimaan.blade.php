<section class="form-section" data-title="Inspeksi Penerimaan Bahan Baku">
    <form action="{{ url('/store-inspeksi-penerimaan') }}" method="post" class="editable-form"
        data-update-url="{{ url('/update-inspeksi-penerimaan/' . ($inspeksiPenerimaan->id ?? '')) }}">
        @csrf
        @if($inspeksiPenerimaan)
            @method('PUT')
        @endif
        <div class="card p-3">
            <input type="hidden" name="type" value="{{ $type ?? 'stock_in' }}">
            @if(isset($type) && $type == 'manual')
                <input type="hidden" name="pm_manual_report_id" value="{{$manual_report->id}}">
            @else
                <input type="hidden" name="stock_in_id" value="{{$master->id}}">
            @endif
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="">Bagian</label>
                    <input type="text" name="bagian" @if($inspeksiPenerimaan)
                    value="{{$inspeksiPenerimaan->bagian}}" disabled @else value="Quality Control" @endif
                        class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Tanggal Inspeksi</label>
                    <input type="date" name="tanggal" @if($inspeksiPenerimaan)
                    value="{{$inspeksiPenerimaan->tanggal->format('Y-m-d')}}" disabled @else
                        value="{{now()->format('Y-m-d')}}" @endif class="form-control border border-1 py-2 px-2">
                </div>
                
                <div class="col-md-4 mb-3">
                    <label for="">Nama Material</label>
                    <input type="text" disabled readonly value="{{$inventory->name}}" class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">No. Batch</label>
                    <input type="text" disabled readonly value="{{$master->nomor_batch}}" class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Expired Date</label>
                    <input type="date" @if(isset($type) && $type != 'manual' && $tanggal_ed != null) disabled readonly @endif name="expired_date" value="{{$tanggal_ed ? \Carbon\Carbon::parse($tanggal_ed)->format('Y-m-d') : ''}}" class="form-control border border-1 py-2 px-2 @if(isset($type) && $type != 'manual' && $tanggal_ed != null) bg-light @endif">
                </div>

                <div class="col-md-4 mb-3">
                    <label for="">Nama Supplier</label>
                    <input type="text" disabled readonly value="{{$master->suplierMaterial->name ?? '-'}}" class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Nama Produsen</label>
                    <select name="manufacturer_id" id="manufacturer_select" class="form-select border border-1 py-2 px-2" @if($inspeksiPenerimaan) disabled @endif required>
                        <option value="">Pilih Produsen</option>
                        @foreach($inventory->manufacturers->unique('id') as $mfg)
                            <option value="{{$mfg->id}}" @if($inspeksiPenerimaan && $inspeksiPenerimaan->manufacturer_id == $mfg->id) selected @endif>{{$mfg->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Negara Produsen</label>
                    <input type="text" id="negara_asal" name="negara_asal" @if($inspeksiPenerimaan) value="{{$inspeksiPenerimaan->negara_asal}}" disabled @endif class="form-control border border-1 py-2 px-2">
                </div>

                <div class="col-md-12 mb-3">
                    <label class="d-block">Dokumen Pendukung</label>
                    <div class="d-flex flex-wrap gap-4 mt-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_coa" value="1" id="doc_coa" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_coa) checked disabled @elseif($inspeksiPenerimaan) disabled @endif>
                            <label class="form-check-label" for="doc_coa">CoA</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_msds" value="1" id="doc_msds" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_msds) checked disabled @elseif($inspeksiPenerimaan) disabled @endif>
                            <label class="form-check-label" for="doc_msds">MSDS</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_halal" value="1" id="doc_halal" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_halal) checked disabled @elseif($inspeksiPenerimaan) disabled @endif>
                            <label class="form-check-label" for="doc_halal">Sertifikat Halal</label>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <label class="text-nowrap mb-0" for="doc_lainnya">Doc. Lainnya</label>
                            <input type="text" name="doc_lainnya" id="doc_lainnya" @if($inspeksiPenerimaan) value="{{$inspeksiPenerimaan->doc_lainnya}}" disabled @endif class="form-control form-control-sm border border-1 px-2 py-1" style="width: 200px;">
                        </div>
                    </div>
                </div>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td class="text-center align-middle" rowspan="2" style="width:25%;">Pemeriksaan</td>
                        <td class="text-center align-middle" rowspan="2" style="width:25%;">Spesifikasi</td>
                        <td class="text-center" colspan="3">Hasil</td>
                    </tr>
                    <tr>
                        <td class="text-center">Atas</td>
                        <td class="text-center">Tengah</td>
                        <td class="text-center">Bawah</td>
                    </tr>
                </thead>
                <tbody>
                    @php
                        $getSpec = function ($section, $param) use ($spesifikasi) {
                            $spec = collect($spesifikasi)->where('section_name', $section)->where('parameter', $param)->first();
                            return $spec ? $spec->spesifikasi : '-';
                        };
                    @endphp
                    <tr>
                        <td>Organoleptis: Bentuk</td>
                        <td><input type="text" disabled readonly value="{{ $getSpec('Organolepis', 'Bentuk') }}"
                                class="form-control border-0 bg-transparent text-center" id="spec_bentuk"></td>
                        <td><input type="text" name="hasil_bentuk_atas" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_bentuk_atas}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_bentuk_tengah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_bentuk_tengah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_bentuk_bawah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_bentuk_bawah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                    </tr>
                    <tr>
                        <td>Organoleptis: Warna</td>
                        <td><input type="text" disabled readonly value="{{ $getSpec('Organolepis', 'Warna') }}"
                                class="form-control border-0 bg-transparent text-center" id="spec_warna"></td>
                        <td><input type="text" name="hasil_warna_atas" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_warna_atas}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_warna_tengah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_warna_tengah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_warna_bawah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_warna_bawah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                    </tr>
                    <tr>
                        <td>Organoleptis: Rasa</td>
                        <td><input type="text" disabled readonly value="{{ $getSpec('Organolepis', 'Rasa') }}"
                                class="form-control border-0 bg-transparent text-center" id="spec_rasa"></td>
                        <td><input type="text" name="hasil_rasa_atas" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_rasa_atas}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_rasa_tengah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_rasa_tengah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                        <td><input type="text" name="hasil_rasa_bawah" @if($inspeksiPenerimaan)
                        value="{{$inspeksiPenerimaan->hasil_rasa_bawah}}" disabled @endif
                                class="form-control border-1 border px-2"></td>
                    </tr>
                </tbody>
            </table>

            <div class="row mt-3">
                <div class="col-md-6 mb-3">
                    <label for="">Kesimpulan</label>
                    <select name="kesimpulan" class="form-select border border-1 py-2 px-2" @if($inspeksiPenerimaan)
                    disabled @endif required>
                        <option value="">Pilih Kesimpulan</option>
                        <option value="Memenuhi Syarat" @if($inspeksiPenerimaan && $inspeksiPenerimaan->kesimpulan == "Memenuhi Syarat") selected @endif>Memenuhi Syarat
                        </option>
                        <option value="Tidak Memenuhi Syarat" @if($inspeksiPenerimaan && $inspeksiPenerimaan->kesimpulan == "Tidak Memenuhi Syarat") selected @endif>Tidak Memenuhi
                            Syarat</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Petugas QC</label>
                    <input type="text" name="petugas_qc" @if($inspeksiPenerimaan) disabled
                    value="{{$inspeksiPenerimaan->petugas_qc}}" @else value="{{Auth::user()->name}}" @endif
                        class="form-control border border-1 py-2 px-2">
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2">
                @if($inspeksiPenerimaan)
                    <button type="button" class="btn btn-sm btn-warning btn-edit">Ubah Data</button>
                    <button type="button" class="btn btn-sm btn-danger btn-cencel d-none">Batalkan</button>
                    <button type="submit" class="btn btn-sm btn-warning btn-save d-none">Simpan Perubahan</button>
                @else
                    <button type="submit" class="btn btn-success">Submit</button>
                @endif
            </div>
        </div>
    </form>
</section>
