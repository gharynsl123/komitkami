<section class="form-section" data-title="Form Pengambilan Sampel Material">
    <form action="{{ url('/store-pengambilan-sampel') }}" method="post" class="editable-form"
        data-update-url="{{ url('/update-pengambilan-sampel/' . ($pengambilanSampel->id ?? '')) }}">
        @csrf
        @if($pengambilanSampel)
            @method('PUT')
        @endif
        <div class="card p-3">
            <input type="hidden" name="type" value="{{ $type ?? 'stock_in' }}">
            @if(isset($type) && $type == 'manual')
                <input type="hidden" name="pm_manual_report_id" value="{{$manual_report->id}}">
            @else
                <input type="hidden" name="stock_in_id" value="{{$master->id}}">
            @endif
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="">Kategori Material</label>
                    <input type="text" name="kategori_material" readonly value="{{$inventory->type}}"
                        class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Nama Material</label>
                    <input type="text" disabled readonly value="{{$inventory->name}}"
                        class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Nomor Bets</label>
                    <input type="text" disabled readonly value="{{$master->nomor_batch ?? "none"}}"
                        class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                @if($inventory->type != 'Bahan Baku')
                <div class="col-md-4 mb-3">
                    <label for="">Nama Supplier</label>
                    <input type="text" disabled readonly value="{{$master->suplierMaterial->name ?? '-'}}"
                        class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Negara Supplier</label>
                    <input type="text" disabled readonly value="{{$master->suplierMaterial->address ?? '-'}}" class="form-control border border-1 py- px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Nama Produsen</label>
                    <select name="manufacturer_id" class="form-select border border-1 py-2 px-2"
                        @if($pengambilanSampel) disabled @endif required>
                        <option value="">Pilih Produsen</option>
                        @foreach($inventory->manufacturers->unique('id') as $mfg)
                            <option value="{{$mfg->id}}" @if($pengambilanSampel && $pengambilanSampel->manufacturer_id == $mfg->id) selected @endif>{{$mfg->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Negara Produsen</label>
                    <input type="text" id="negara_asal" name="negara_asal" @if($pengambilanSampel) value="{{$pengambilanSampel->negara_pemasok ?? ''}}" disabled @endif class="form-control border border-1 py-2 px-2 bg-light" readonly>
                </div>
                @else
                <div class="col-md-4 mb-3">
                    <label for="">Nama Supplier</label>
                    <input type="text" disabled readonly value="{{$master->suplierMaterial->name ?? '-'}}"
                        class="form-control border border-1 py-2 px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Negara Supplier</label>
                    <input type="text" disabled readonly value="{{$master->suplierMaterial->address ?? '-'}}" class="form-control border border-1 py- px-2 bg-light">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Nama Produsen</label>
                    <select name="manufacturer_id" id="manufacturer_select" class="form-select border border-1 py-2 px-2" @if($inspeksiPenerimaan) disabled @endif required>
                        <option value="">Pilih Produsen</option>
                        @foreach($inventory->manufacturers->unique('id') as $mfg)
                            <option value="{{$mfg->id}}" @if($inspeksiPenerimaan && $inspeksiPenerimaan->manufacturer_id == $mfg->id) selected @endif>{{$mfg->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="">Negara Produsen</label>
                    <input type="text" id="negara_asal" name="negara_asal" @if($inspeksiPenerimaan) value="{{$inspeksiPenerimaan->negara_asal}}" disabled @endif class="form-control border border-1 py-2 px-2 bg-light" readonly>
                </div>
                @endif
                <div class="col-md-6 mb-3">
                    <label for="">Tanggal Sampling</label>
                    <input type="date" name="tanggal_sampling" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->tanggal_sampling->format('Y-m-d')}}" disabled @else
                        value="{{now()->format('Y-m-d')}}" @endif required
                        class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Expired Date</label>
                    <input type="date" name="expired_date" @if($pengambilanSampel)
                        value="{{$pengambilanSampel->expired_date ? $pengambilanSampel->expired_date->format('Y-m-d') : ''}}"
                    @if(isset($type) && $type != 'manual') disabled @endif @else
                        value="{{$tanggal_ed ? $tanggal_ed->format('Y-m-d') : ''}}" @endif
                        @if(isset($type) && $type != 'manual' && $tanggal_ed != null) disabled readonly @endif
                        class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Jumlah Barang Datang</label>
                    <input type="number" name="jumlah_barang_datang" 
                        @if($pengambilanSampel)
                            value="{{ rtrim(rtrim(number_format($pengambilanSampel->jumlah_barang_datang, 3, '.', ''), '0'), '.') }}"
                            disabled
                            class="form-control border border-1 py-2 px-2 bg-light"
                        @else
                            @if($type == 'manual')
                                class="form-control border border-1 py-2 px-2 bg-light" required
                            @else
                                value="{{ rtrim(rtrim(number_format($stok, 3, '.', ''), '0'), '.') }}"
                                readonly
                                class="form-control border border-1 py-2 px-2 bg-light"
                            @endif
                        @endif
                    >
                </div>
                <div class="col-md-6 mb-3">
                    <label class="d-block">Dokumen Pendukung</label>
                    <div class="d-flex flex-wrap gap-4 mt-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_coa" value="1" id="doc_coa" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_coa) checked disabled @endif>
                            <label class="form-check-label" for="doc_coa">CoA</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_msds" value="1" id="doc_msds" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_msds) checked disabled @endif>
                            <label class="form-check-label" for="doc_msds">MSDS</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="doc_halal" value="1" id="doc_halal" @if($inspeksiPenerimaan && $inspeksiPenerimaan->doc_halal) checked disabled @endif>
                            <label class="form-check-label" for="doc_halal">Sertifikat Halal</label>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <label class="text-nowrap mb-0" for="doc_lainnya">Doc. Lainnya</label>
                            <input type="text" name="doc_lainnya" id="doc_lainnya" @if($inspeksiPenerimaan) value="{{$inspeksiPenerimaan->doc_lainnya}}" disabled @endif class="form-control form-control-sm border border-1 px-2 py-1" style="width: 200px;">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Referensi Metode Sampling</label>
                    <input type="text" name="referensi_metode" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->referensi_metode}}" disabled @endif placeholder="Isi referensi"
                        class="form-control border border-1 py-2 px-2">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="">Jumlah Sampel Diambil</label>
                    <input type="text" name="jumlah_sampel" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->jumlah_sampel}}" disabled @endif required
                        placeholder="Misal: 50 gram" class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Peralatan Sampling</label>
                    <input type="text" name="peralatan_sampling" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->peralatan_sampling}}" disabled @endif required
                        class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Lokasi Sampling</label>
                    <input type="text" name="lokasi_sampling" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->lokasi_sampling}}" disabled @endif required
                        class="form-control border border-1 py-2 px-2">
                </div>

                <div class="col-md-6 mb-3">
                    <label for="">Disampling Oleh</label>
                    <input type="text" name="disampling_oleh" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->disampling_oleh}}" disabled @else
                        value="{{Auth::user()->name}}" @endif class="form-control border border-1 py-2 px-2">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="">Diperiksa Oleh</label>
                    <input type="text" name="diperiksa_oleh" @if($pengambilanSampel)
                    value="{{$pengambilanSampel->diperiksa_oleh}}" disabled @endif
                        class="form-control border border-1 py-2 px-2">
                </div>

                <div class="col-md-12 mb-3">
                    <label>Catatan</label>
                    <textarea name="catatan" @if($pengambilanSampel) disabled @endif
                        placeholder="Catatan (opsional)"
                        class="form-control border border-1 py-2 px-2">@if($pengambilanSampel){{$pengambilanSampel->catatan}}@endif</textarea>
                </div>
            </div>
            <div class="d-flex justify-content-end gap-2">
                @if($pengambilanSampel)
                    <button type="button" class="btn btn-sm btn-warning btn-edit">Ubah Data</button>
                    <button type="button" class="btn btn-sm btn-danger btn-cencel d-none">Batalkan</button>
                    <button type="submit" class="btn btn-sm btn-warning btn-save d-none">Simpan Perubahan</button>
                @else
                    <button type="submit" class="btn btn-success">Submit</button>
                @endif
            </div>
        </div>
    </form>
</section>
<script>
$(document).ready(function() {

    $('#dokumen_pendukung').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Pilih dokumen...',
        tags: true,
        allowClear: true
    });

});
</script>
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css"
    rel="stylesheet" />
